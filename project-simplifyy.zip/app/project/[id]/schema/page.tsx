import { AppShell } from "@/components/app-shell"
import { ProjectNav } from "@/components/project-nav"
import { SchemaWorkspace } from "@/components/schema/schema-workspace"
import { getProject } from "@/lib/mock-data"

export default async function SchemaPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const project = getProject(id)

  return (
    <AppShell>
      <ProjectNav projectId={project.id} projectName={project.name} active="schema" />
      <main className="flex-1 p-6">
        <SchemaWorkspace />
      </main>
    </AppShell>
  )
}
